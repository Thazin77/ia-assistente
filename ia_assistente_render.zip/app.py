
from flask import Flask, render_template, request, jsonify
import openai, os
from dotenv import load_dotenv
from serpapi import GoogleSearch

load_dotenv()

openai.api_key = os.getenv("OPENAI_API_KEY")
SERPAPI_KEY = os.getenv("SERPAPI_API_KEY")

app = Flask(__name__)

def responder_openai(pergunta):
    try:
        resposta = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": pergunta}],
            max_tokens=500,
            temperature=0.7
        )
        return resposta['choices'][0]['message']['content'].strip()
    except Exception as e:
        return f"Erro OpenAI: {e}"

def buscar_serpapi(pergunta):
    try:
        params = {
            "q": pergunta,
            "api_key": SERPAPI_KEY,
            "engine": "google",
            "num": 1,
        }
        search = GoogleSearch(params)
        results = search.get_dict()
        return results.get("organic_results", [{}])[0].get("snippet", "Nada encontrado.")
    except Exception as e:
        return f"Erro Google: {e}"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/perguntar", methods=["POST"])
def perguntar():
    pergunta = request.json.get("pergunta")
    resposta = responder_openai(pergunta)

    if "não sei" in resposta.lower() or len(resposta) < 20:
        resposta += "\n\n🌐 Google diz: " + buscar_serpapi(pergunta)

    return jsonify({"resposta": resposta})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
